// ============================================================
// Tanzania School Management System — C++ Backend Server
// A lightweight HTTP server with REST API and JSON file storage
// ============================================================
// Build:  g++ -std=c++17 -O2 -pthread -o server server.cpp
// Run:    ./server [port]   (default: 8080)
// ============================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <thread>
#include <mutex>
#include <filesystem>
#include <algorithm>
#include <chrono>
#include <ctime>
#include <map>
#include <vector>
#include <functional>
#include <csignal>

// POSIX networking
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

namespace fs = std::filesystem;

// ─── Global State ────────────────────────────────────────────
static const std::string DATA_FILE    = "data.json";
static const std::string STATIC_DIR   = "public";
static const std::string BACKUP_DIR   = "backups";
static int               server_fd    = -1;
static std::mutex         data_mutex;
static volatile bool      running     = true;

// ─── Utility: Read entire file into string ───────────────────
std::string readFile(const std::string& path) {
    std::ifstream ifs(path, std::ios::binary);
    if (!ifs) return "";
    std::ostringstream oss;
    oss << ifs.rdbuf();
    return oss.str();
}

// ─── Utility: Write string to file atomically ────────────────
bool writeFile(const std::string& path, const std::string& content) {
    std::string tmp = path + ".tmp";
    {
        std::ofstream ofs(tmp, std::ios::binary);
        if (!ofs) return false;
        ofs << content;
        ofs.flush();
        if (!ofs) return false;
    }
    return std::rename(tmp.c_str(), path.c_str()) == 0;
}

// ─── Utility: Get MIME type from extension ───────────────────
std::string getMimeType(const std::string& path) {
    static const std::map<std::string, std::string> types = {
        {".html", "text/html; charset=utf-8"},
        {".css",  "text/css; charset=utf-8"},
        {".js",   "application/javascript; charset=utf-8"},
        {".json", "application/json; charset=utf-8"},
        {".png",  "image/png"},
        {".jpg",  "image/jpeg"},
        {".jpeg", "image/jpeg"},
        {".gif",  "image/gif"},
        {".svg",  "image/svg+xml"},
        {".ico",  "image/x-icon"},
        {".woff", "font/woff"},
        {".woff2","font/woff2"},
        {".ttf",  "font/ttf"},
    };
    auto ext = fs::path(path).extension().string();
    std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
    auto it = types.find(ext);
    return (it != types.end()) ? it->second : "application/octet-stream";
}

// ─── Utility: URL-decode ─────────────────────────────────────
std::string urlDecode(const std::string& s) {
    std::string out;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '%' && i + 2 < s.size()) {
            int val;
            std::istringstream iss(s.substr(i + 1, 2));
            if (iss >> std::hex >> val) {
                out += static_cast<char>(val);
                i += 2;
            } else out += s[i];
        } else if (s[i] == '+') out += ' ';
        else out += s[i];
    }
    return out;
}

// ─── Utility: Get current timestamp string ───────────────────
std::string timestamp() {
    auto now = std::chrono::system_clock::now();
    auto t   = std::chrono::system_clock::to_time_t(now);
    char buf[64];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", std::localtime(&t));
    return std::string(buf);
}

std::string dateStamp() {
    auto now = std::chrono::system_clock::now();
    auto t   = std::chrono::system_clock::to_time_t(now);
    char buf[32];
    std::strftime(buf, sizeof(buf), "%Y%m%d_%H%M%S", std::localtime(&t));
    return std::string(buf);
}

// ─── HTTP Request Parser ─────────────────────────────────────
struct HttpRequest {
    std::string method;
    std::string path;
    std::string query;
    std::map<std::string, std::string> headers;
    std::string body;
};

HttpRequest parseRequest(const std::string& raw) {
    HttpRequest req;
    std::istringstream iss(raw);
    std::string line;

    // Request line
    if (std::getline(iss, line)) {
        std::istringstream rline(line);
        rline >> req.method >> req.path;
        // Separate query string
        auto qpos = req.path.find('?');
        if (qpos != std::string::npos) {
            req.query = req.path.substr(qpos + 1);
            req.path  = req.path.substr(0, qpos);
        }
    }

    // Headers
    while (std::getline(iss, line) && line != "\r" && !line.empty()) {
        if (line.back() == '\r') line.pop_back();
        auto colon = line.find(':');
        if (colon != std::string::npos) {
            std::string key = line.substr(0, colon);
            std::string val = line.substr(colon + 1);
            while (!val.empty() && val[0] == ' ') val.erase(0, 1);
            std::transform(key.begin(), key.end(), key.begin(), ::tolower);
            req.headers[key] = val;
        }
    }

    // Body (rest of the data)
    auto bodyStart = raw.find("\r\n\r\n");
    if (bodyStart != std::string::npos) {
        req.body = raw.substr(bodyStart + 4);
    }

    return req;
}

// ─── HTTP Response Builder ───────────────────────────────────
std::string buildResponse(int code, const std::string& contentType,
                          const std::string& body,
                          const std::map<std::string, std::string>& extraHeaders = {}) {
    static const std::map<int, std::string> phrases = {
        {200, "OK"}, {201, "Created"}, {204, "No Content"},
        {400, "Bad Request"}, {404, "Not Found"}, {405, "Method Not Allowed"},
        {500, "Internal Server Error"}
    };
    auto it = phrases.find(code);
    std::string phrase = it != phrases.end() ? it->second : "Unknown";

    std::ostringstream resp;
    resp << "HTTP/1.1 " << code << " " << phrase << "\r\n";
    resp << "Content-Type: " << contentType << "\r\n";
    resp << "Content-Length: " << body.size() << "\r\n";
    resp << "Access-Control-Allow-Origin: *\r\n";
    resp << "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n";
    resp << "Access-Control-Allow-Headers: Content-Type\r\n";
    resp << "Connection: close\r\n";
    for (auto& [k, v] : extraHeaders) {
        resp << k << ": " << v << "\r\n";
    }
    resp << "\r\n" << body;
    return resp.str();
}

std::string jsonResponse(int code, const std::string& json) {
    return buildResponse(code, "application/json; charset=utf-8", json);
}

std::string jsonError(int code, const std::string& message) {
    return jsonResponse(code, "{\"error\":\"" + message + "\"}");
}

std::string jsonOk(const std::string& message = "ok") {
    return jsonResponse(200, "{\"status\":\"" + message + "\"}");
}

// ─── Data Operations ─────────────────────────────────────────
std::string loadData() {
    std::lock_guard<std::mutex> lock(data_mutex);
    std::string content = readFile(DATA_FILE);
    if (content.empty()) {
        // Return default empty state
        content = R"({
  "students": [],
  "att": {},
  "attLog": [],
  "exams": [],
  "history": [],
  "nid": 1,
  "sn": ""
})";
        writeFile(DATA_FILE, content);
    }
    return content;
}

bool saveData(const std::string& jsonData) {
    std::lock_guard<std::mutex> lock(data_mutex);
    return writeFile(DATA_FILE, jsonData);
}

bool createBackup() {
    std::lock_guard<std::mutex> lock(data_mutex);
    if (!fs::exists(DATA_FILE)) return false;
    fs::create_directories(BACKUP_DIR);
    std::string dest = BACKUP_DIR + "/data_" + dateStamp() + ".json";
    try {
        fs::copy_file(DATA_FILE, dest);
        return true;
    } catch (...) {
        return false;
    }
}

std::string listBackups() {
    std::string json = "[";
    bool first = true;
    if (fs::exists(BACKUP_DIR)) {
        std::vector<std::string> files;
        for (auto& entry : fs::directory_iterator(BACKUP_DIR)) {
            if (entry.path().extension() == ".json")
                files.push_back(entry.path().filename().string());
        }
        std::sort(files.rbegin(), files.rend());
        for (auto& f : files) {
            if (!first) json += ",";
            json += "\"" + f + "\"";
            first = false;
        }
    }
    json += "]";
    return json;
}

// ─── Route Handler ───────────────────────────────────────────
std::string handleRequest(const HttpRequest& req) {
    // CORS preflight
    if (req.method == "OPTIONS") {
        return buildResponse(204, "text/plain", "");
    }

    // ── API Routes ──
    if (req.path == "/api/data") {
        if (req.method == "GET") {
            return jsonResponse(200, loadData());
        }
        if (req.method == "POST" || req.method == "PUT") {
            if (req.body.empty()) return jsonError(400, "Empty body");
            if (saveData(req.body)) {
                std::cout << "[" << timestamp() << "] Data saved (" 
                          << req.body.size() << " bytes)\n";
                return jsonOk("saved");
            }
            return jsonError(500, "Failed to save data");
        }
        return jsonError(405, "Method not allowed");
    }

    if (req.path == "/api/backup") {
        if (req.method == "POST") {
            if (createBackup()) return jsonOk("backup_created");
            return jsonError(500, "Backup failed");
        }
        if (req.method == "GET") {
            return jsonResponse(200, listBackups());
        }
        return jsonError(405, "Method not allowed");
    }

    if (req.path == "/api/health") {
        std::string info = "{\"status\":\"running\",\"timestamp\":\"" + timestamp()
                         + "\",\"data_file\":\"" + DATA_FILE + "\"}";
        return jsonResponse(200, info);
    }

    if (req.path == "/api/export") {
        if (req.method == "GET") {
            std::string data = loadData();
            std::map<std::string, std::string> headers;
            headers["Content-Disposition"] = "attachment; filename=\"sms_export_" + dateStamp() + ".json\"";
            return buildResponse(200, "application/json", data, headers);
        }
        return jsonError(405, "Method not allowed");
    }

    // ── Static File Serving ──
    std::string filePath = STATIC_DIR;
    if (req.path == "/" || req.path == "/index.html") {
        filePath += "/index.html";
    } else {
        filePath += urlDecode(req.path);
    }

    // Prevent path traversal
    auto canonical = fs::weakly_canonical(filePath);
    auto root      = fs::weakly_canonical(STATIC_DIR);
    if (canonical.string().substr(0, root.string().size()) != root.string()) {
        return jsonError(403, "Forbidden");
    }

    if (fs::exists(filePath) && fs::is_regular_file(filePath)) {
        std::string content = readFile(filePath);
        return buildResponse(200, getMimeType(filePath), content);
    }

    return jsonError(404, "Not found: " + req.path);
}

// ─── Client Handler (one per connection) ─────────────────────
void handleClient(int clientFd) {
    // Read request with buffering
    std::string raw;
    char buf[8192];
    bool headersDone = false;
    size_t contentLength = 0;

    while (true) {
        ssize_t n = recv(clientFd, buf, sizeof(buf), 0);
        if (n <= 0) break;
        raw.append(buf, n);

        if (!headersDone) {
            auto hdrEnd = raw.find("\r\n\r\n");
            if (hdrEnd != std::string::npos) {
                headersDone = true;
                // Parse content-length
                std::string lowerRaw = raw;
                std::transform(lowerRaw.begin(), lowerRaw.end(), lowerRaw.begin(), ::tolower);
                auto clPos = lowerRaw.find("content-length:");
                if (clPos != std::string::npos) {
                    auto valStart = clPos + 15;
                    auto valEnd   = lowerRaw.find("\r\n", valStart);
                    std::string clStr = raw.substr(valStart, valEnd - valStart);
                    try { contentLength = std::stoul(clStr); } catch (...) {}
                }
                size_t bodyReceived = raw.size() - (hdrEnd + 4);
                if (bodyReceived >= contentLength) break;
            }
        } else {
            auto hdrEnd = raw.find("\r\n\r\n");
            size_t bodyReceived = raw.size() - (hdrEnd + 4);
            if (bodyReceived >= contentLength) break;
        }
    }

    if (!raw.empty()) {
        HttpRequest req = parseRequest(raw);
        std::string response = handleRequest(req);

        // Log request
        std::cout << "[" << timestamp() << "] "
                  << req.method << " " << req.path;
        if (!req.query.empty()) std::cout << "?" << req.query;
        std::cout << "\n";

        // Send response
        size_t totalSent = 0;
        while (totalSent < response.size()) {
            ssize_t sent = send(clientFd, response.c_str() + totalSent,
                                response.size() - totalSent, MSG_NOSIGNAL);
            if (sent <= 0) break;
            totalSent += sent;
        }
    }

    close(clientFd);
}

// ─── Signal Handler ──────────────────────────────────────────
void signalHandler(int sig) {
    std::cout << "\n[" << timestamp() << "] Shutting down (signal " << sig << ")...\n";
    running = false;
    if (server_fd >= 0) close(server_fd);
}

// ─── Main ────────────────────────────────────────────────────
int main(int argc, char* argv[]) {
    int port = 8080;
    if (argc > 1) {
        try { port = std::stoi(argv[1]); } catch (...) {
            std::cerr << "Usage: " << argv[0] << " [port]\n";
            return 1;
        }
    }

    // Create static directory if not exists
    fs::create_directories(STATIC_DIR);

    // Register signal handlers
    std::signal(SIGINT,  signalHandler);
    std::signal(SIGTERM, signalHandler);
    std::signal(SIGPIPE, SIG_IGN);

    // Create socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        std::cerr << "Error: Could not create socket\n";
        return 1;
    }

    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr{};
    addr.sin_family      = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port        = htons(port);

    if (bind(server_fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        std::cerr << "Error: Could not bind to port " << port << "\n";
        close(server_fd);
        return 1;
    }

    if (listen(server_fd, 64) < 0) {
        std::cerr << "Error: Listen failed\n";
        close(server_fd);
        return 1;
    }

    std::cout << R"(
  ╔══════════════════════════════════════════════════════╗
  ║    🇹🇿  Tanzania School Management System  🇹🇿       ║
  ║    ─────────────────────────────────────────         ║
  ║    C++ HTTP Server                                   ║
  ╚══════════════════════════════════════════════════════╝
)" << std::endl;
    std::cout << "  Server running on: http://localhost:" << port << "\n";
    std::cout << "  Static files:      ./" << STATIC_DIR << "/\n";
    std::cout << "  Data file:         ./" << DATA_FILE << "\n";
    std::cout << "  Backups:           ./" << BACKUP_DIR << "/\n";
    std::cout << "\n  API Endpoints:\n";
    std::cout << "    GET  /api/data     — Load all data\n";
    std::cout << "    POST /api/data     — Save all data\n";
    std::cout << "    POST /api/backup   — Create backup\n";
    std::cout << "    GET  /api/backup   — List backups\n";
    std::cout << "    GET  /api/export   — Download data as file\n";
    std::cout << "    GET  /api/health   — Server health check\n";
    std::cout << "\n  Press Ctrl+C to stop.\n\n";

    // Accept loop
    while (running) {
        struct sockaddr_in clientAddr{};
        socklen_t clientLen = sizeof(clientAddr);
        int clientFd = accept(server_fd, (struct sockaddr*)&clientAddr, &clientLen);

        if (clientFd < 0) {
            if (running) std::cerr << "[WARN] Accept failed\n";
            continue;
        }

        // Set recv timeout
        struct timeval tv{5, 0};
        setsockopt(clientFd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

        // Handle in detached thread
        std::thread(handleClient, clientFd).detach();
    }

    close(server_fd);
    std::cout << "[" << timestamp() << "] Server stopped.\n";
    return 0;
}
