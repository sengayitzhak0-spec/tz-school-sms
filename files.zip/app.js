// ============================================================
// Tanzania School Management System — JavaScript Client
// Communicates with C++ backend via REST API
// ============================================================

// ======= CURRICULUM DATA =======
// Form 1-2: All core subjects same for everyone
const F12_SUBJECTS = ["Mathematics","English Language","Kiswahili","Biology","Physics","Chemistry","History","Geography","Civics","Religion"];

// Form 3-4: Core for ALL + stream-specific
const F34_CORE = ["Mathematics","English Language","Kiswahili","Biology","Civics"];
const F34_SCIENCE = ["Physics","Chemistry","Geography","History"];
const F34_ARTS = ["History","Geography","Fine Art","Music","French"];
const F34_BUSINESS = ["Book Keeping","Commerce","History","Geography"];

// A-Level combos
const COMBOS = {
  PCB:{n:"Physics, Chemistry, Biology",s:["Physics","Chemistry","Biology","General Studies","BAM"]},
  PCM:{n:"Physics, Chemistry, Mathematics",s:["Physics","Chemistry","Advanced Mathematics","General Studies","BAM"]},
  CBG:{n:"Chemistry, Biology, Geography",s:["Chemistry","Biology","Geography","General Studies","BAM"]},
  PGM:{n:"Physics, Geography, Mathematics",s:["Physics","Geography","Advanced Mathematics","General Studies","BAM"]},
  HGL:{n:"History, Geography, Language",s:["History","Geography","Kiswahili/English Lit","General Studies","BAM"]},
  HGE:{n:"History, Geography, Economics",s:["History","Geography","Economics","General Studies","BAM"]},
  HGK:{n:"History, Geography, Kiswahili",s:["History","Geography","Kiswahili","General Studies","BAM"]},
  HKL:{n:"History, Kiswahili, Language",s:["History","Kiswahili","English Lit/French","General Studies","BAM"]},
  CBN:{n:"Chemistry, Biology, Nutrition",s:["Chemistry","Biology","Food & Nutrition","General Studies","BAM"]},
  ECA:{n:"Economics, Commerce, Accountancy",s:["Economics","Commerce","Accountancy","General Studies","BAM"]},
  EGM:{n:"Economics, Geography, Mathematics",s:["Economics","Geography","Advanced Mathematics","General Studies","BAM"]},
  HKE:{n:"History, Kiswahili, Economics",s:["History","Kiswahili","Economics","General Studies","BAM"]},
  CBA:{n:"Chemistry, Biology, Agriculture",s:["Chemistry","Biology","Agriculture","General Studies","BAM"]}
};

const REGIONS = ["Arusha","Dar es Salaam","Dodoma","Geita","Iringa","Kagera","Katavi","Kigoma","Kilimanjaro","Lindi","Manyara","Mara","Mbeya","Mjini Magharibi","Morogoro","Mtwara","Mwanza","Njombe","Pemba Kaskazini","Pemba Kusini","Pwani","Rukwa","Ruvuma","Shinyanga","Simiyu","Singida","Songwe","Tabora","Tanga","Unguja Kaskazini","Unguja Kusini"];

// ======= STATE =======
let D = { students: [], att: {}, attLog: [], exams: [], history: [], nid: 1, sn: "" };
let eid = null;        // editing student id
let droppedSubs = [];  // subjects removed during registration
let saveTimer = null;  // debounce timer for auto-save

// ======= DOM HELPERS =======
const $ = id => document.getElementById(id);

// ======= API LAYER (communicates with C++ server) =======
const API = {
  async loadData() {
    try {
      const resp = await fetch('/api/data');
      if (!resp.ok) throw new Error('Load failed');
      const data = await resp.json();
      // Ensure all expected fields exist
      if (!data.att)     data.att = {};
      if (!data.attLog)  data.attLog = [];
      if (!data.exams)   data.exams = [];
      if (!data.history) data.history = [];
      if (!data.nid)     data.nid = 1;
      if (!data.sn)      data.sn = "";
      return data;
    } catch (e) {
      console.error('API loadData error:', e);
      return null;
    }
  },

  async saveData(data) {
    try {
      const resp = await fetch('/api/data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!resp.ok) throw new Error('Save failed');
      return true;
    } catch (e) {
      console.error('API saveData error:', e);
      return false;
    }
  },

  async checkHealth() {
    try {
      const resp = await fetch('/api/health');
      return resp.ok;
    } catch (e) {
      return false;
    }
  },

  async createBackup() {
    try {
      const resp = await fetch('/api/backup', { method: 'POST' });
      return resp.ok;
    } catch (e) {
      return false;
    }
  }
};

// ======= SAVE (debounced, sends to C++ server) =======
function sv() {
  // Debounce: wait 300ms after last change before saving
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    const ok = await API.saveData(D);
    if (!ok) console.warn('Failed to save to server');
  }, 300);
}

// ======= LOAD DATA FROM SERVER =======
async function ld() {
  const data = await API.loadData();
  if (data) {
    D = data;
    if (D.sn) {
      $('sn-setup').style.display = 'none';
      $('sn-show').style.display = 'block';
      $('sn-title').textContent = '🏫 ' + D.sn;
    }
  }
}

// ======= SERVER STATUS MONITOR =======
async function checkServer() {
  const ok = await API.checkHealth();
  const dot = $('status-dot');
  const txt = $('status-text');
  if (ok) {
    dot.className = 'dot connected';
    txt.textContent = 'C++ Server Online';
  } else {
    dot.className = 'dot disconnected';
    txt.textContent = 'Server Offline';
  }
}

// ======= GRADING HELPERS =======
const grO = m => {
  if (m >= 75) return { g: "A", p: 1, r: "Excellent" };
  if (m >= 65) return { g: "B", p: 2, r: "Very Good" };
  if (m >= 45) return { g: "C", p: 3, r: "Good" };
  if (m >= 30) return { g: "D", p: 4, r: "Satisfactory" };
  return { g: "F", p: 5, r: "Fail" };
};

const grA = m => {
  if (m >= 80) return { g: "A", p: 1, r: "Excellent" };
  if (m >= 70) return { g: "B", p: 2, r: "Very Good" };
  if (m >= 60) return { g: "C", p: 3, r: "Good" };
  if (m >= 50) return { g: "D", p: 4, r: "Satisfactory" };
  if (m >= 40) return { g: "E", p: 5, r: "Poor" };
  if (m >= 35) return { g: "S", p: 6, r: "Subsidiary" };
  return { g: "F", p: 7, r: "Fail" };
};

const gr = (m, f) => f >= 5 ? grA(m) : grO(m);

const dv = (pts, f) => {
  if (f >= 5) {
    if (pts >= 3 && pts <= 9)  return "I";
    if (pts <= 12) return "II";
    if (pts <= 17) return "III";
    if (pts <= 19) return "IV";
    return "0";
  }
  if (pts >= 7 && pts <= 17) return "I";
  if (pts <= 21) return "II";
  if (pts <= 25) return "III";
  if (pts <= 33) return "IV";
  return "0";
};

function getSubs(s) {
  if (!s) return [];
  let base = [];
  if (s.form >= 5 && s.combo && COMBOS[s.combo]) base = [...COMBOS[s.combo].s];
  else if (s.form <= 2) base = [...F12_SUBJECTS];
  else if (s.form <= 4) {
    base = [...F34_CORE];
    if (s.stream === "Science") base.push(...F34_SCIENCE);
    else if (s.stream === "Arts") base.push(...F34_ARTS);
    else if (s.stream === "Business") base.push(...F34_BUSINESS);
    base = [...new Set(base)];
  }
  if (s.dropped && s.dropped.length) base = base.filter(x => !s.dropped.includes(x));
  return base;
}

function abI(sid) {
  let t = 0;
  const ds = Object.keys(D.att).sort();
  ds.forEach(d => { if (D.att[d]?.[sid] === "A") t++; });
  if (t < 30) return { f: false, d: t };
  let k = 0;
  for (const d of [...ds].reverse()) {
    const r = D.att[d]?.[sid];
    if (r === "P") k++;
    else if (r === "A") break;
  }
  return { f: k < 30, d: t };
}

// ======= MOBILE MENU =======
function toggleMenu() { $('sb').classList.toggle('open'); $('overlay').classList.toggle('open'); }
function closeMenu()  { $('sb').classList.remove('open'); $('overlay').classList.remove('open'); }

// ======= NAVIGATION =======
function refreshTab(t) {
  if (t === 'dash') rDash();
  if (t === 'list') rList();
  if (t === 'att')  rAtt();
  if (t === 'atth') rAttHist();
  if (t === 'exam') xFC();
  if (t === 'rep')  rFC();
  if (t === 'hist') initHist();
}

document.querySelectorAll('#sb nav a').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    const t = a.dataset.t;
    document.querySelectorAll('#sb nav a').forEach(x => x.classList.remove('on'));
    a.classList.add('on');
    document.querySelectorAll('.pg').forEach(p => p.classList.remove('on'));
    $('p-' + t).classList.add('on');
    refreshTab(t);
    closeMenu();
  });
});

function goTab(t) {
  document.querySelectorAll('#sb nav a').forEach(x => { x.classList.toggle('on', x.dataset.t === t); });
  document.querySelectorAll('.pg').forEach(p => p.classList.remove('on'));
  $('p-' + t).classList.add('on');
  refreshTab(t);
  closeMenu();
}

// ======= SCHOOL NAME =======
function saveSN() {
  const n = $('sn-inp').value.trim();
  if (!n) { alert('Enter school name'); return; }
  D.sn = n;
  $('sn-setup').style.display = 'none';
  $('sn-show').style.display = 'block';
  $('sn-title').textContent = '🏫 ' + n;
  sv();
}

function editSN() {
  $('sn-setup').style.display = 'block';
  $('sn-show').style.display = 'none';
  $('sn-inp').value = D.sn;
}

// ======= BACKUP =======
async function createBackup() {
  const ok = await API.createBackup();
  $('backup-msg').textContent = ok ? '✅ Backup created!' : '❌ Backup failed';
  setTimeout(() => $('backup-msg').textContent = '', 3000);
}

// ======= INIT =======
async function init() {
  REGIONS.forEach(r => {
    const o = document.createElement('option');
    o.value = r; o.textContent = r;
    $('r-reg').appendChild(o);
  });
  Object.entries(COMBOS).forEach(([k, v]) => {
    const o = document.createElement('option');
    o.value = k; o.textContent = k + ' — ' + v.n;
    $('r-combo').appendChild(o);
  });
  $('ad').value = new Date().toISOString().split('T')[0];
  $('ah-month').value = new Date().toISOString().slice(0, 7);

  await ld();
  rDash();
  checkServer();
  setInterval(checkServer, 30000); // Check server every 30s
}

// ======= DASHBOARD =======
function rDash() {
  const n = D.students.length;
  const fc = {};
  for (let i = 1; i <= 6; i++) fc[i] = D.students.filter(s => s.form === i).length;
  const td = new Date().toISOString().split('T')[0];
  const tr = D.att[td] || {};
  const tv = Object.values(tr);

  $('d-stats').innerHTML = [
    { t: 'Total', v: n, s: `${D.students.filter(s => s.gender === 'Male').length}M · ${D.students.filter(s => s.gender === 'Female').length}F`, c: '#e94560' },
    { t: 'O-Level', v: fc[1] + fc[2] + fc[3] + fc[4], s: 'Form 1-4', c: '#0f3460' },
    { t: 'A-Level', v: fc[5] + fc[6], s: 'Form 5-6', c: '#533483' },
    { t: 'Today', v: `${tv.filter(v => v === 'P').length}P/${tv.filter(v => v === 'A').length}A/${tv.filter(v => v === 'L').length}L`, s: `of ${n}`, c: '#16c79a' }
  ].map(x => `<div class="cd" style="border-left:4px solid ${x.c};flex:1 1 160px;min-width:140px"><div style="font-size:10px;color:#888;font-weight:700;text-transform:uppercase">${x.t}</div><div style="font-size:26px;font-weight:800;color:#1a1a2e;margin-top:3px">${x.v}</div><div style="font-size:10px;color:#aaa;margin-top:3px">${x.s}</div></div>`).join('');

  let b = '<h3 style="font-size:14px;margin-bottom:12px;color:#1a1a2e">Students per Form</h3>';
  for (let f = 1; f <= 6; f++) {
    const p = n ? Math.max((fc[f] / n) * 100, fc[f] ? 5 : 0) : 0;
    b += `<div style="display:flex;align-items:center;gap:8px;margin-bottom:5px"><span style="width:50px;font-size:11px;color:#555">Form ${f}</span><div style="flex:1;height:18px;background:#eee;border-radius:9px;overflow:hidden"><div style="width:${p}%;height:100%;background:${f <= 4 ? '#0f3460' : '#533483'};border-radius:9px;display:flex;align-items:center;justify-content:flex-end;padding-right:5px;font-size:9px;color:#fff;font-weight:700;min-width:${fc[f] ? '18px' : '0'}">${fc[f] || ''}</div></div></div>`;
  }
  $('d-bars').innerHTML = b;
}

// ======= REGISTRATION =======
function onFC() {
  const f = +$('r-form').value;
  $('stream-wrap').style.display = (f === 3 || f === 4) ? 'block' : 'none';
  $('combo-sec').style.display = f >= 5 ? 'block' : 'none';
  if (f < 3 || f > 4) $('r-stream').value = '';
  if (f < 5) $('r-combo').value = '';
  droppedSubs = [];
  showSubjects();
}

function onSC() { droppedSubs = []; showSubjects(); }

function onCC() {
  const c = $('r-combo').value;
  $('combo-subs').innerHTML = c && COMBOS[c] ? '<b style="color:#533483">Subjects:</b> ' + COMBOS[c].s.join(', ') : '';
  showSubjects();
}

function showSubjects() {
  const f = +$('r-form').value;
  let allSubs = [];
  if (f <= 2) allSubs = [...F12_SUBJECTS];
  else if (f <= 4) {
    const st = $('r-stream').value;
    if (st) {
      allSubs = [...F34_CORE];
      if (st === 'Science')  allSubs.push(...F34_SCIENCE);
      else if (st === 'Arts')     allSubs.push(...F34_ARTS);
      else if (st === 'Business') allSubs.push(...F34_BUSINESS);
      allSubs = [...new Set(allSubs)];
    }
  } else {
    const c = $('r-combo').value;
    if (c && COMBOS[c]) allSubs = [...COMBOS[c].s];
  }
  droppedSubs = droppedSubs.filter(x => allSubs.includes(x));
  if (allSubs.length) {
    const active = allSubs.filter(x => !droppedSubs.includes(x));
    $('subj-display').style.display = 'block';
    let h = '<div style="margin-bottom:6px;font-size:11px;color:#888">Click a subject to remove it. Click again to add it back. <b style="color:#0f3460">' + active.length + '/' + allSubs.length + '</b> subjects active.</div>';
    h += allSubs.map(s => {
      const off = droppedSubs.includes(s);
      return `<span onclick="togSub('${s.replace(/'/g, "\\'")}')" style="display:inline-block;padding:4px 12px;border-radius:14px;margin:2px;font-size:11px;cursor:pointer;user-select:none;transition:all .15s;${off ? 'background:#fce4ec;color:#c62828;border:1.5px solid #e94560;text-decoration:line-through' : 'background:#e8eaf6;color:#1a1a2e;border:1.5px solid #c5cae9'}">${off ? '✗ ' : '✓ '}${s}</span>`;
    }).join('');
    $('subj-list').innerHTML = h;
  } else {
    $('subj-display').style.display = 'none';
  }
}

function togSub(s) {
  if (droppedSubs.includes(s)) droppedSubs = droppedSubs.filter(x => x !== s);
  else droppedSubs.push(s);
  showSubjects();
}

function doReg() {
  ['e-fn', 'e-ln', 'e-adm', 'e-combo', 'e-stream'].forEach(id => $(id).textContent = '');
  const fn = $('r-fn').value.trim();
  const mn = $('r-mn').value.trim();
  const ln = $('e-ln-w').value.trim();
  const gen = $('r-gen').value;
  const dob = $('r-dob').value;
  const form = +$('r-form').value;
  const stream = $('r-stream').value;
  const combo = $('r-combo').value;
  const adm = $('r-adm').value.trim();
  const pn = $('r-pn').value.trim();
  const ph = $('r-ph').value.trim();
  const ad = $('r-ad').value.trim();
  const reg = $('r-reg').value;
  const prev = $('r-prev').value.trim();
  const olidx = $('r-olidx').value.trim();

  let ok = true;
  if (!fn) { $('e-fn').textContent = 'Required'; ok = false; }
  if (!ln) { $('e-ln').textContent = 'Required'; ok = false; }
  if ((form === 3 || form === 4) && !stream) { $('e-stream').textContent = 'Select a stream'; ok = false; }
  if (form >= 5 && !combo) { $('e-combo').textContent = 'Required'; ok = false; }
  if (adm) {
    const dp = D.students.find(s => s.adm === adm && s.id !== (eid ?? -1));
    if (dp) { $('e-adm').textContent = 'Already exists'; ok = false; }
  }
  if (!ok) return;

  const data = {
    fn, mn, ln, gender: gen, dob, form,
    stream: (form === 3 || form === 4) ? stream : '',
    combo: form >= 5 ? combo : '',
    adm, pn, ph, ad, reg, prev, olidx,
    dropped: [...droppedSubs]
  };

  if (eid !== null) {
    const i = D.students.findIndex(s => s.id === eid);
    if (i >= 0) D.students[i] = { ...data, id: eid };
    $('r-msg').innerHTML = `<div class="ok">✅ ${fn} ${ln} updated!</div>`;
    eid = null;
    $('r-tt').textContent = 'Student Registration';
    $('r-can').style.display = 'none';
    $('r-btn').textContent = '✓ Register Student';
  } else {
    data.id = D.nid++;
    D.students.push(data);
    $('r-msg').innerHTML = `<div class="ok">✅ ${fn} ${ln} registered successfully!</div>`;
  }
  sv();
  clrReg();
  setTimeout(() => $('r-msg').innerHTML = '', 5000);
}

function clrReg() {
  ['r-fn', 'r-mn', 'e-ln-w', 'r-dob', 'r-adm', 'r-pn', 'r-ph', 'r-ad', 'r-prev', 'r-olidx'].forEach(id => $(id).value = '');
  $('r-gen').value = 'Male';
  $('r-form').value = '1';
  $('r-stream').value = '';
  $('r-combo').value = '';
  $('r-reg').value = '';
  droppedSubs = [];
  onFC();
}

function editSt(id) {
  const s = D.students.find(x => x.id === id);
  if (!s) return;
  eid = id;
  $('r-fn').value = s.fn;
  $('r-mn').value = s.mn;
  $('e-ln-w').value = s.ln;
  $('r-gen').value = s.gender;
  $('r-dob').value = s.dob || '';
  $('r-form').value = s.form;
  $('r-stream').value = s.stream || '';
  $('r-combo').value = s.combo || '';
  $('r-adm').value = s.adm || '';
  $('r-pn').value = s.pn || '';
  $('r-ph').value = s.ph || '';
  $('r-ad').value = s.ad || '';
  $('r-reg').value = s.reg || '';
  $('r-prev').value = s.prev || '';
  $('r-olidx').value = s.olidx || '';
  droppedSubs = s.dropped ? [...s.dropped] : [];
  onFC(); onCC();
  $('r-tt').textContent = 'Edit Student';
  $('r-can').style.display = 'inline-block';
  $('r-btn').textContent = '✓ Update Student';
  goTab('reg');
}

function canEdit() {
  eid = null;
  clrReg();
  $('r-tt').textContent = 'Student Registration';
  $('r-can').style.display = 'none';
  $('r-btn').textContent = '✓ Register Student';
  $('r-msg').innerHTML = '';
}

// ======= STUDENT LIST =======
function rList() {
  const q = ($('ls').value || '').toLowerCase();
  const ff = $('lf').value;
  const fl = D.students.filter(s => {
    if (ff !== 'all' && s.form !== +ff) return false;
    if (q) return (s.fn + ' ' + s.mn + ' ' + s.ln + ' ' + s.adm).toLowerCase().includes(q);
    return true;
  });
  $('lc').textContent = D.students.length;
  if (!fl.length) {
    $('lb2').innerHTML = `<tr><td colspan="8" style="padding:36px;text-align:center;color:#bbb">${D.students.length ? 'No results.' : 'No students yet.'}</td></tr>`;
    return;
  }
  $('lb2').innerHTML = fl.map((s, i) => {
    const ab = abI(s.id);
    const sc = s.form >= 5 ? (s.combo || '—') : s.form >= 3 ? (s.stream || '—') : 'All Core';
    return `<tr class="${ab.f ? 'fl' : ''}"><td>${i + 1}</td><td style="font-weight:600">${s.adm || '—'}</td><td>${s.fn} ${s.mn} ${s.ln}${ab.f ? `<span style="margin-left:5px;font-size:9px;color:#c62828;background:#ffcdd2;padding:1px 5px;border-radius:3px;font-weight:700">⚠${ab.d}d</span>` : ''}</td><td><span class="bge" style="background:${s.gender === 'Male' ? '#e3f2fd' : '#fce4ec'};color:${s.gender === 'Male' ? '#1565c0' : '#c62828'}">${s.gender}</span></td><td>F${s.form}</td><td>${sc}</td><td>${s.reg || '—'}</td><td><button class="bt bb bs" onclick="editSt(${s.id})">Edit</button> <button class="bt bd bs" onclick="cDel(${s.id})">Del</button></td></tr>`;
  }).join('');
}

function cDel(id) {
  const s = D.students.find(x => x.id === id);
  if (!s) return;
  $('dm').innerHTML = `<div class="mo"><div class="md"><h3 style="color:#c62828">⚠ Delete?</h3><p style="font-size:13px;color:#555;margin-top:8px">Delete <b>${s.fn} ${s.ln}</b>?</p><div style="margin-top:14px;text-align:right"><button class="bt bx bs" onclick="$('dm').innerHTML=''">Cancel</button> <button class="bt bd bs" onclick="doDel(${id})">Delete</button></div></div></div>`;
}

function doDel(id) {
  D.students = D.students.filter(s => s.id !== id);
  Object.keys(D.att).forEach(d => { if (D.att[d]?.[id]) delete D.att[d][id]; });
  D.exams = D.exams.filter(e => e.sid !== id);
  sv();
  $('dm').innerHTML = '';
  rList();
}

// ======= ATTENDANCE =======
let attTemp = {};

function rAtt() {
  const date = $('ad').value, frm = +$('af').value;
  const sts = D.students.filter(s => s.form === frm);
  const saved = D.att[date + '-' + frm];
  if (saved) attTemp = { ...saved }; else attTemp = {};
  renderAttUI(date, frm, sts);
}

function renderAttUI(date, frm, sts) {
  const logKey = date + '-' + frm;
  const submitted = D.attLog.find(l => l.key === logKey);

  if (submitted) {
    $('att-status').innerHTML = `<div style="padding:8px 14px;background:#e8f5e9;border:1.5px solid #4caf50;border-radius:8px;font-size:12px;color:#2e7d32;display:flex;align-items:center;gap:6px"><span style="font-size:16px">✅</span> <b>Submitted</b> on ${submitted.time} — ${submitted.p}P / ${submitted.a}A / ${submitted.l}L of ${submitted.total}</div>`;
  } else {
    const marked = sts.filter(s => attTemp[s.id]).length;
    const unmarked = sts.length - marked;
    if (sts.length) {
      $('att-status').innerHTML = `<div style="padding:8px 14px;background:#fff3e0;border:1.5px solid #ff9800;border-radius:8px;font-size:12px;color:#e65100;display:flex;align-items:center;gap:6px"><span style="font-size:16px">⏳</span> <b>Not submitted</b> — ${marked} marked, ${unmarked} unmarked</div>`;
    } else {
      $('att-status').innerHTML = '';
    }
  }

  let p = 0, a = 0, l = 0;
  sts.forEach(s => { const v = attTemp[s.id]; if (v === 'P') p++; else if (v === 'A') a++; else if (v === 'L') l++; });
  $('as').innerHTML = [
    { l: 'Present(P)', v: p, c: '#16c79a', b: '#e8f5e9' },
    { l: 'Absent(A)', v: a, c: '#e94560', b: '#fce4ec' },
    { l: 'Late(L)', v: l, c: '#f5a623', b: '#fff8e1' },
    { l: 'Unmarked', v: sts.length - p - a - l, c: '#999', b: '#f5f5f5' },
    { l: 'Total', v: sts.length, c: '#333', b: '#e8eaf6' }
  ].map(x => `<div class="sb" style="background:${x.b}"><div class="sn" style="color:${x.c}">${x.v}</div><div class="st" style="color:${x.c}">${x.l}</div></div>`).join('');

  if (!sts.length) {
    $('ab').innerHTML = '<tr><td colspan="5" style="padding:36px;text-align:center;color:#bbb">No students.</td></tr>';
    $('att-submit-area').innerHTML = '';
    return;
  }

  $('ab').innerHTML = sts.map((s, i) => {
    const c = attTemp[s.id] || '';
    const ab = abI(s.id);
    const dot = c ? `<span style="display:inline-block;width:30px;height:30px;line-height:30px;border-radius:50%;background:${c === 'P' ? '#16c79a' : c === 'A' ? '#e94560' : '#f5a623'};color:#fff;font-weight:800;font-size:13px;text-align:center">${c}</span>` : '<span style="color:#ccc">—</span>';
    return `<tr class="${ab.f ? 'fl' : ''}"><td>${i + 1}</td><td style="font-weight:600;font-size:11px">${s.adm || '—'}</td><td><span style="color:${ab.f ? '#c62828' : '#333'}">${s.fn} ${s.mn} ${s.ln}</span>${ab.f ? `<span style="margin-left:5px;font-size:9px;background:#ffcdd2;padding:1px 5px;border-radius:3px;color:#c62828;font-weight:700">${ab.d}d</span>` : ''}</td><td style="text-align:center">${dot}</td><td style="text-align:center"><span class="at ${c === 'P' ? 'aP' : ''}" onclick="sAt(${s.id},'P')">P</span><span class="at ${c === 'A' ? 'aA' : ''}" onclick="sAt(${s.id},'A')">A</span><span class="at ${c === 'L' ? 'aL' : ''}" onclick="sAt(${s.id},'L')">L</span></td></tr>`;
  }).join('');

  const anyMarked = sts.some(s => attTemp[s.id]);
  $('att-submit-area').innerHTML = anyMarked
    ? `<button class="bt bg" onclick="submitAtt()" style="font-size:14px;padding:12px 30px">✓ Submit Attendance for ${date} (Form ${frm})</button>${submitted ? '<button class="bt bx" onclick="submitAtt()" style="font-size:12px;padding:10px 20px">Update Submission</button>' : ''}`
    : '<span style="font-size:12px;color:#888">Mark students then submit.</span>';
}

function sAt(sid, st) {
  if (attTemp[sid] === st) delete attTemp[sid]; else attTemp[sid] = st;
  const date = $('ad').value, frm = +$('af').value;
  const sts = D.students.filter(s => s.form === frm);
  renderAttUI(date, frm, sts);
}

function mAll(st) {
  const frm = +$('af').value;
  D.students.filter(s => s.form === frm).forEach(s => { attTemp[s.id] = st; });
  const date = $('ad').value;
  const sts = D.students.filter(s => s.form === frm);
  renderAttUI(date, frm, sts);
}

function submitAtt() {
  const date = $('ad').value, frm = +$('af').value;
  const sts = D.students.filter(s => s.form === frm);
  const unmarked = sts.filter(s => !attTemp[s.id]);

  if (unmarked.length > 0) {
    if (!confirm(unmarked.length + ' student(s) are unmarked. Submit anyway?\n\nUnmarked: ' + unmarked.map(s => s.fn + ' ' + s.ln).join(', '))) return;
  }

  const logKey = date + '-' + frm;
  if (!D.att[logKey]) D.att[logKey] = {};
  if (!D.att[date]) D.att[date] = {};
  sts.forEach(s => {
    if (attTemp[s.id]) {
      D.att[logKey][s.id] = attTemp[s.id];
      D.att[date][s.id] = attTemp[s.id];
    }
  });

  let p = 0, a = 0, l = 0;
  sts.forEach(s => { const v = attTemp[s.id]; if (v === 'P') p++; else if (v === 'A') a++; else if (v === 'L') l++; });

  const now = new Date().toLocaleString();
  const logEntry = { key: logKey, date, form: frm, time: now, p, a, l, total: sts.length, records: {} };
  sts.forEach(s => {
    logEntry.records[s.id] = { name: s.fn + ' ' + (s.mn || '') + ' ' + s.ln, adm: s.adm || '', status: attTemp[s.id] || '—' };
  });

  const existIdx = D.attLog.findIndex(x => x.key === logKey);
  if (existIdx >= 0) D.attLog[existIdx] = logEntry; else D.attLog.push(logEntry);

  sv();
  $('att-msg').innerHTML = '<div class="ok">✅ Attendance submitted for ' + date + ' (Form ' + frm + ') — ' + p + 'P / ' + a + 'A / ' + l + 'L <button class="bt bb bs" onclick="goTab(\'atth\')" style="margin-left:10px">View History →</button></div>';
  setTimeout(() => $('att-msg').innerHTML = '', 5000);
  renderAttUI(date, frm, sts);
}

// ======= ATTENDANCE HISTORY =======
function rAttHist() {
  const ff = $('ah-form').value;
  const mo = $('ah-month').value;
  const sq = ($('ah-search').value || '').toLowerCase().trim();
  let logs = [...D.attLog].sort((a, b) => b.date.localeCompare(a.date));
  if (ff !== 'all') logs = logs.filter(l => l.form === +ff);
  if (mo) logs = logs.filter(l => l.date.startsWith(mo));

  if (sq) {
    logs = logs.filter(l => {
      const recs = Object.values(l.records || {});
      return recs.some(r => (r.name || '').toLowerCase().includes(sq) || (r.adm || '').toLowerCase().includes(sq));
    });
  }

  if (!logs.length) {
    $('ah-area').innerHTML = '<div class="cd" style="text-align:center;color:#bbb;padding:32px">' + (D.attLog.length ? 'No records match filter.' : 'No attendance submitted yet.') + '</div>';
    return;
  }

  let totalP = 0, totalA = 0, totalL = 0;
  logs.forEach(l => { totalP += l.p; totalA += l.a; totalL += l.l; });
  let h = `<div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <div class="sb" style="background:#e8f5e9"><div class="sn" style="color:#16c79a">${totalP}</div><div class="st" style="color:#16c79a">Total Present</div></div>
    <div class="sb" style="background:#fce4ec"><div class="sn" style="color:#e94560">${totalA}</div><div class="st" style="color:#e94560">Total Absent</div></div>
    <div class="sb" style="background:#fff8e1"><div class="sn" style="color:#f5a623">${totalL}</div><div class="st" style="color:#f5a623">Total Late</div></div>
    <div class="sb" style="background:#e8eaf6"><div class="sn" style="color:#333">${logs.length}</div><div class="st" style="color:#333">Records</div></div>
  </div>`;

  logs.forEach(l => {
    let recs = Object.entries(l.records || {}).map(([id, r]) => ({ id, name: r.name, adm: r.adm, status: r.status }));
    const filtering = !!sq;
    if (filtering) {
      recs = recs.filter(r => (r.name || '').toLowerCase().includes(sq) || (r.adm || '').toLowerCase().includes(sq));
    }
    h += `<div class="cd" style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:10px">
        <div><b style="font-size:14px;color:#0f3460">${l.date}</b> <span style="font-size:11px;color:#888">— Form ${l.form}</span></div>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <span style="padding:2px 8px;background:#e8f5e9;border-radius:6px;font-size:11px;font-weight:600;color:#2e7d32">${l.p}P</span>
          <span style="padding:2px 8px;background:#fce4ec;border-radius:6px;font-size:11px;font-weight:600;color:#c62828">${l.a}A</span>
          <span style="padding:2px 8px;background:#fff8e1;border-radius:6px;font-size:11px;font-weight:600;color:#e65100">${l.l}L</span>
          <span style="font-size:10px;color:#888">of ${l.total}</span>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;font-size:10px;color:#aaa">Submitted: ${l.time}
        <button class="bt bd bs" onclick="delAttLog('${l.key}')" style="padding:2px 8px;font-size:10px;margin-left:auto">Delete</button>
      </div>`;
    if (filtering) h += `<div style="font-size:10px;color:#0f3460;margin-bottom:6px;font-weight:600">Showing ${recs.length} matching student(s)</div>`;
    h += `<div class="tbl-wrap"><table style="font-size:11px;min-width:300px"><thead><tr><th>#</th><th>Adm</th><th>Name</th><th style="text-align:center">Status</th></tr></thead><tbody>`;
    recs.forEach((r, i) => {
      const col = r.status === 'P' ? '#16c79a' : r.status === 'A' ? '#e94560' : r.status === 'L' ? '#f5a623' : '#999';
      const hl = filtering ? 'background:#fffde7;' : '';
      h += `<tr style="${hl}"><td>${i + 1}</td><td style="font-weight:600">${r.adm || '—'}</td><td>${r.name}</td><td style="text-align:center"><span style="display:inline-block;width:26px;height:26px;line-height:26px;border-radius:50%;background:${col};color:#fff;font-weight:800;font-size:11px;text-align:center">${r.status}</span></td></tr>`;
    });
    h += `</tbody></table></div></div>`;
  });

  $('ah-area').innerHTML = h;
}

function delAttLog(key) {
  if (!confirm('Delete this attendance record?')) return;
  D.attLog = D.attLog.filter(l => l.key !== key);
  if (D.att[key]) delete D.att[key];
  sv();
  rAttHist();
}

// ======= EXAMS =======
function xFC() {
  const f = +$('xf').value;
  const sel = $('xs');
  const sts = D.students.filter(s => s.form === f);
  sel.innerHTML = '<option value="">Choose... (' + sts.length + ' students)</option>';
  sts.forEach(s => {
    const o = document.createElement('option');
    o.value = s.id;
    o.textContent = (s.adm ? s.adm + ' — ' : '') + s.fn + ' ' + s.ln;
    sel.appendChild(o);
  });
  $('xa').style.display = 'none';
  $('xa').innerHTML = sts.length ? '' : '<div style="text-align:center;color:#e94560;padding:20px">⚠ No students in Form ' + f + '.</div>';
  if (!sts.length) $('xa').style.display = 'block';
}

function xSC() {
  const sid = +$('xs').value;
  const stu = D.students.find(s => s.id === sid);
  if (!stu) { $('xa').style.display = 'none'; return; }
  const subs = getSubs(stu);
  const en = $('xt').value, tm = $('xm').value;
  const ex = D.exams.find(e => e.sid === sid && e.exam === en && e.term === tm);
  const mk = ex ? ex.marks : {};
  const isA = stu.form >= 5;

  let ref = isA
    ? '<b>NECTA A-Level (ACSEE) Grading:</b> A: 80-100 (1pt) | B: 70-79 (2pts) | C: 60-69 (3pts) | D: 50-59 (4pts) | E: 40-49 (5pts) | S: 35-39 (6pts) | F: 0-34 (7pts)'
    : '<b>NECTA O-Level (CSEE) Grading:</b> A: 75-100 (1pt) | B: 65-74 (2pts) | C: 45-64 (3pts) | D: 30-44 (4pts) | F: 0-29 (5pts)';

  let h = `<div style="padding:10px 14px;background:#fffde7;border:1px solid #ffe082;border-radius:8px;font-size:11px;color:#5d4037;margin-bottom:14px">${ref}</div>`;
  h += `<div style="margin-bottom:12px;display:flex;justify-content:space-between;align-items:center"><div><b>${stu.fn} ${stu.ln}</b><span style="margin-left:8px;font-size:11px;color:#888">Form ${stu.form}${stu.stream ? ' · ' + stu.stream : ''}${stu.combo ? ' · ' + stu.combo : ''}</span></div>${ex ? '<span style="font-size:10px;color:#16c79a;font-weight:700;background:#e8f5e9;padding:2px 8px;border-radius:10px">✓ Editing existing</span>' : ''}</div>`;
  h += `<div class="tbl-wrap"><table><thead><tr style="background:#1a1a2e;color:#fff"><th style="width:30px">#</th><th>Subject</th><th style="text-align:center;width:80px">Marks (0-100)</th><th style="text-align:center;width:55px">Grade</th><th style="text-align:center;width:55px">Points</th><th>Remark</th></tr></thead><tbody>`;
  subs.forEach((sub, i) => {
    const v = mk[sub] || '';
    const n = v !== '' ? +v : NaN;
    const g = !isNaN(n) ? gr(n, stu.form) : null;
    h += `<tr><td style="color:#888;text-align:center">${i + 1}</td><td style="font-weight:500">${sub}</td><td style="text-align:center"><input type="number" min="0" max="100" value="${v}" id="mk-${i}" data-s="${sub}" oninput="xCalc()" style="width:60px;padding:5px;border:2px solid #ddd;border-radius:6px;text-align:center;font-size:13px;font-weight:600"></td><td style="text-align:center;font-weight:800;font-size:15px;color:${g ? gcol(g.g) : '#ccc'}" id="gd-${i}">${g ? g.g : '—'}</td><td style="text-align:center;font-weight:700;color:#444" id="gp-${i}">${g ? g.p : '—'}</td><td style="font-size:11px" id="gr-${i}"><span style="color:${g ? gcol(g.g) : '#ccc'};font-weight:500">${g ? g.r : '—'}</span></td></tr>`;
  });
  h += `</tbody></table></div>`;
  h += `<div id="ex-summary" style="margin-top:14px;padding:14px;background:#f5f5f5;border-radius:8px;display:flex;flex-wrap:wrap;gap:14px;align-items:center"></div>`;
  h += `<div style="margin-top:14px;text-align:right"><button class="bt" onclick="svEx()">💾 Save Results</button></div>`;
  $('xa').innerHTML = h;
  $('xa').style.display = 'block';
  xCalc();
}

function gcol(g) {
  return g === 'A' ? '#16c79a' : g === 'B' ? '#2196f3' : g === 'C' ? '#ff9800' : g === 'D' ? '#9c27b0' : g === 'E' ? '#e65100' : g === 'S' ? '#795548' : g === 'F' ? '#e94560' : '#999';
}

function xCalc() {
  const sid = +$('xs').value;
  const stu = D.students.find(s => s.id === sid);
  if (!stu) return;
  const subs = getSubs(stu);
  const isA = stu.form >= 5;
  let total = 0, cnt = 0, allGrades = [];

  subs.forEach((sub, i) => {
    const el = $('mk-' + i);
    if (!el) return;
    const v = el.value;
    const n = v !== '' ? +v : NaN;
    const gd = $('gd-' + i), gp = $('gp-' + i), gre = $('gr-' + i);
    if (!isNaN(n) && n >= 0 && n <= 100) {
      const g = gr(n, stu.form);
      gd.textContent = g.g; gd.style.color = gcol(g.g);
      gp.textContent = g.p;
      gre.innerHTML = `<span style="color:${gcol(g.g)};font-weight:500">${g.r}</span>`;
      total += n; cnt++;
      allGrades.push({ sub, g: g.g, p: g.p });
    } else {
      gd.textContent = '—'; gd.style.color = '#ccc';
      gp.textContent = '—';
      gre.innerHTML = '<span style="color:#ccc">—</span>';
    }
  });

  const sm = $('ex-summary');
  if (!sm) return;
  if (cnt === 0) { sm.innerHTML = '<span style="color:#aaa;font-size:12px">Enter marks to see summary...</span>'; return; }
  const avg = (total / cnt).toFixed(1);
  const best = [...allGrades].sort((a, b) => a.p - b.p).slice(0, isA ? 3 : 7);
  const pts = best.reduce((s, r) => s + r.p, 0);
  const div = dv(pts, stu.form);
  const divCol = div === 'I' ? '#16c79a' : div === 'II' ? '#2196f3' : div === 'III' ? '#ff9800' : div === 'IV' ? '#e65100' : '#e94560';

  sm.innerHTML = `
    <div class="sb" style="background:#e8f5e9"><div class="sn" style="color:#333">${total}</div><div class="st" style="color:#666">Total Marks</div></div>
    <div class="sb" style="background:#e3f2fd"><div class="sn" style="color:#0f3460">${avg}%</div><div class="st" style="color:#666">Average</div></div>
    <div class="sb" style="background:#fff3e0"><div class="sn" style="color:#e65100">${pts}</div><div class="st" style="color:#666">Best ${isA ? '3' : '7'} Pts</div></div>
    <div class="sb" style="background:${div === 'I' ? '#e8f5e9' : div === 'II' ? '#e3f2fd' : div === 'III' ? '#fff3e0' : '#fce4ec'}"><div class="sn" style="color:${divCol}">${div === '0' ? 'Fail' : 'Div ' + div}</div><div class="st" style="color:#666">Division</div></div>
    <div style="font-size:10px;color:#888;margin-left:10px">NECTA: ${isA ? 'Best 3 principal subjects' : 'Best 7 subjects'} | Div I: ${isA ? '3-9' : '7-17'} | Div II: ${isA ? '10-12' : '18-21'} | Div III: ${isA ? '13-17' : '22-25'} | Div IV: ${isA ? '18-19' : '26-33'}</div>`;
}

function svEx() {
  const sid = +$('xs').value;
  const stu = D.students.find(s => s.id === sid);
  if (!stu) return;
  const subs = getSubs(stu);
  const mk = {};
  let any = false;
  subs.forEach((sub, i) => {
    const el = $('mk-' + i);
    if (el) { const v = el.value; mk[sub] = v; if (v !== '') any = true; }
  });
  if (!any) { alert('Enter at least one mark'); return; }
  const data = { sid, exam: $('xt').value, term: $('xm').value, yr: $('xy').value, marks: mk, form: stu.form, combo: stu.combo || '', stream: stu.stream || '' };
  const i = D.exams.findIndex(e => e.sid === sid && e.exam === data.exam && e.term === data.term);
  if (i >= 0) D.exams[i] = data; else D.exams.push(data);
  sv();
  $('exm').innerHTML = '<div class="ok">✅ Results saved!</div>';
  setTimeout(() => $('exm').innerHTML = '', 3000);
  xSC();
}

// ======= REPORT =======
function rFC() {
  const f = +$('rf').value;
  const sel = $('rs');
  const sts = D.students.filter(s => s.form === f);
  sel.innerHTML = '<option value="">Choose... (' + sts.length + ' students)</option>';
  sts.forEach(s => {
    const o = document.createElement('option');
    o.value = s.id;
    o.textContent = (s.adm ? s.adm + ' — ' : '') + s.fn + ' ' + s.ln;
    sel.appendChild(o);
  });
  $('ra').innerHTML = sts.length
    ? '<div class="cd" style="text-align:center;color:#bbb;padding:32px">Select a student to view report.</div>'
    : '<div class="cd" style="text-align:center;color:#e94560;padding:32px">⚠ No students registered in Form ' + f + '. Register students first.</div>';
}

function rRep() {
  const sid = +$('rs').value;
  const stu = D.students.find(s => s.id === sid);
  const en = $('rt').value, tm = $('rm').value;
  if (!stu) { $('ra').innerHTML = '<div class="cd" style="text-align:center;color:#bbb;padding:32px">Select student.</div>'; return; }
  const res = D.exams.find(e => e.sid === sid && e.exam === en && e.term === tm);
  if (!res) { $('ra').innerHTML = `<div class="cd" style="text-align:center;color:#bbb;padding:32px">No results for <b style="color:#555">${stu.fn} ${stu.ln}</b> — ${en} (${tm}).</div>`; return; }

  const isA = stu.form >= 5;
  const subs = getSubs(stu);
  const sr = subs.map(sub => { const m = parseInt(res.marks[sub]) || 0; const g = gr(m, stu.form); return { sub, m, g: g.g, p: g.p, r: g.r }; });
  const tot = sr.reduce((s, r) => s + r.m, 0);
  const avg = subs.length ? (tot / subs.length).toFixed(1) : '0';
  const best = [...sr].sort((a, b) => a.p - b.p).slice(0, isA ? 3 : 7);
  const pts = best.reduce((s, r) => s + r.p, 0);
  const div = dv(pts, stu.form);
  const fst = D.students.filter(s => s.form === stu.form);
  const avgs = fst.map(fs => {
    const fr = D.exams.find(e => e.sid === fs.id && e.exam === en && e.term === tm);
    if (!fr) return { id: fs.id, a: 0 };
    const fsubs = getSubs(fs);
    const ft = fsubs.reduce((s, sub) => s + (parseInt(fr.marks[sub]) || 0), 0);
    return { id: fs.id, a: fsubs.length ? ft / fsubs.length : 0 };
  }).sort((a, b) => b.a - a.a);
  const rank = avgs.findIndex(a => a.id === stu.id) + 1;
  const sn = D.sn || 'School Name Not Set';
  const streamInfo = stu.stream ? ` · ${stu.stream} Stream` : '';
  const comboInfo = stu.combo ? ` · ${stu.combo} — ${COMBOS[stu.combo]?.n || ''}` : '';

  // Grading table rows
  const gradingRows = isA
    ? [['A','80-100',1,'Excellent'],['B','70-79',2,'Very Good'],['C','60-69',3,'Good'],['D','50-59',4,'Satisfactory'],['E','40-49',5,'Poor'],['S','35-39',6,'Subsidiary'],['F','0-34',7,'Fail']]
    : [['A','75-100',1,'Excellent'],['B','65-74',2,'Very Good'],['C','45-64',3,'Good'],['D','30-44',4,'Satisfactory'],['F','0-29',5,'Fail']];
  const gradingRowsHtml = gradingRows.map((r, i) => `<tr${i % 2 ? ' style="background:#fafafa"' : ''}><td style="padding:3px 8px;font-weight:700;color:${gcol(r[0])}">${r[0]}</td><td style="padding:3px 8px">${r[1]}</td><td style="padding:3px 8px;text-align:center">${r[2]}</td><td style="padding:3px 8px">${r[3]}</td></tr>`).join('');

  $('ra').innerHTML = `<div id="prp"><div style="background:#fff;border-radius:12px;box-shadow:0 2px 14px rgba(0,0,0,.06);overflow:hidden">
  <div class="rh"><div style="font-size:9px;letter-spacing:3px;text-transform:uppercase;opacity:.5">United Republic of Tanzania</div><div style="font-size:20px;font-weight:800;margin-top:5px">${sn}</div><div style="font-size:15px;font-weight:700;margin-top:3px">STUDENT ACADEMIC REPORT</div><div style="font-size:11px;opacity:.7;margin-top:3px">${en} — ${tm} ${res.yr || '2025'}</div></div>
  <div style="padding:14px 26px;border-bottom:2px solid #f0f0f0"><div class="g g3" style="font-size:12px">
    <div><span style="color:#888">Name:</span> <b>${stu.fn} ${stu.mn || ''} ${stu.ln}</b></div>
    ${stu.adm ? `<div><span style="color:#888">Adm:</span> <b>${stu.adm}</b></div>` : ''}
    <div><span style="color:#888">Gender:</span> <b>${stu.gender}</b></div>
    <div><span style="color:#888">Form:</span> <b>${stu.form} ${isA ? '(A-Level)' : '(O-Level)'}${streamInfo}${comboInfo}</b></div>
    <div><span style="color:#888">Rank:</span> <b>${rank} of ${fst.length}</b></div>
  </div></div>
  <div style="padding:14px 26px"><div class="tbl-wrap"><table style="border:1px solid #e0e0e0"><thead><tr>${['#', 'Subject', 'Marks', 'Grade', 'Pts', 'Remark'].map(h => `<th style="text-align:${h === 'Subject' || h === 'Remark' ? 'left' : 'center'}">${h}</th>`).join('')}</tr></thead><tbody>${sr.map((r, i) => `<tr><td style="text-align:center;color:#888">${i + 1}</td><td style="font-weight:500">${r.sub}</td><td style="text-align:center;font-weight:700">${r.m}</td><td style="text-align:center;font-weight:800;font-size:14px;color:${gcol(r.g)}">${r.g}</td><td style="text-align:center;font-weight:600">${r.p}</td><td style="font-size:11px;color:${gcol(r.g)};font-weight:500">${r.r}</td></tr>`).join('')}</tbody><tfoot><tr style="background:#f5f5f5;font-weight:700"><td colspan="2" style="padding:8px 10px">Total / Average</td><td style="text-align:center;padding:8px">${tot} / ${avg}%</td><td colspan="3"></td></tr></tfoot></table></div></div>
  <div style="padding:0 26px 20px;display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px">
    <div class="sc" style="background:#f0f8ff;border:1px solid #d4e8f5;border-radius:8px"><div class="sl">Best ${isA ? '3' : '7'} Pts</div><div class="sv" style="color:#0f3460">${pts}</div><div class="ss">${best.map(s => s.sub.slice(0, 4)).join(', ')}</div></div>
    <div class="sc" style="background:${div === 'I' ? '#e8f5e9' : div === 'II' ? '#e3f2fd' : div === 'III' ? '#fff8e1' : '#fce4ec'};border:1px solid #ddd;border-radius:8px"><div class="sl">Division</div><div class="sv">${div === '0' ? 'Fail' : 'Div ' + div}</div><div class="ss">${isA ? 'A-Level' : 'O-Level'}</div></div>
    <div class="sc" style="background:#fafafa;border:1px solid #eee;border-radius:8px"><div class="sl">Average</div><div class="sv">${avg}%</div></div>
    <div class="sc" style="background:#f3e5f5;border:1px solid #ce93d8;border-radius:8px"><div class="sl">Rank</div><div class="sv" style="color:#6a1b9a">${rank}</div><div class="ss">of ${fst.length}</div></div>
  </div>
  <div style="padding:0 26px 18px"><div style="font-size:10px;font-weight:700;color:#888;margin-bottom:6px">NECTA ${isA ? 'A-LEVEL (ACSEE)' : 'O-LEVEL (CSEE)'} GRADING SYSTEM</div><table style="font-size:10px;border:1px solid #e0e0e0;width:auto"><thead><tr style="background:#1a1a2e;color:#fff"><th style="padding:4px 8px">Grade</th><th style="padding:4px 8px">Marks</th><th style="padding:4px 8px">Points</th><th style="padding:4px 8px">Remark</th></tr></thead><tbody>${gradingRowsHtml}</tbody></table><div style="margin-top:6px;font-size:10px;color:#888">Division calculated from best ${isA ? '3 principal subjects (3-9=I, 10-12=II, 13-17=III, 18-19=IV)' : '7 subjects (7-17=I, 18-21=II, 22-25=III, 26-33=IV)'}</div></div>
  <div style="padding:10px 26px;background:#fafafa;border-top:1px solid #eee;display:flex;justify-content:space-between;font-size:10px;color:#bbb"><span>Generated: ${new Date().toLocaleDateString()}</span><span>${sn}</span></div>
  </div></div>
  <div style="margin-top:14px;display:flex;gap:10px">
    <button class="bt bb" onclick="dlRep()">⬇ Download Report</button>
    <button class="bt bg" onclick="prRep()">🖨 Print Report</button>
  </div>`;
}

function dlRep() {
  const el = $('prp');
  if (!el) return;
  const h = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Report</title><style>body{font-family:'Segoe UI',sans-serif;margin:20px;color:#333}table{width:100%;border-collapse:collapse;font-size:12px;border:1px solid #ccc}th{background:#1a1a2e;color:#fff;padding:8px;text-align:left;font-size:10px;text-transform:uppercase}td{padding:7px 8px;border-bottom:1px solid #eee}.rh{background:#1a1a2e;color:#fff;padding:22px;text-align:center;border-radius:10px 10px 0 0}.sc{display:inline-block;padding:12px;border-radius:8px;text-align:center;margin:4px;min-width:110px;border:1px solid #ddd}.sl{font-size:9px;color:#888;text-transform:uppercase}.sv{font-size:22px;font-weight:800}.ss{font-size:9px;color:#aaa}</style></head><body>${el.innerHTML}</body></html>`;
  const b = new Blob([h], { type: 'text/html' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(b);
  const s = D.students.find(s => s.id === +$('rs').value);
  a.download = (s ? s.fn + '_' + s.ln : 'report') + '_report.html';
  a.click();
  URL.revokeObjectURL(a.href);
}

function prRep() {
  const el = $('prp');
  if (!el) return;
  const w = window.open('', '', 'width=800,height=600');
  w.document.write(`<!DOCTYPE html><html><head><title>Report</title><style>body{font-family:'Segoe UI',sans-serif;margin:20px}table{width:100%;border-collapse:collapse;font-size:12px;border:1px solid #ccc}th{background:#1a1a2e;color:#fff;padding:8px;text-align:left;font-size:10px;-webkit-print-color-adjust:exact;print-color-adjust:exact}td{padding:7px 8px;border-bottom:1px solid #eee}.rh{background:#1a1a2e;color:#fff;padding:22px;text-align:center;-webkit-print-color-adjust:exact;print-color-adjust:exact}.sc{display:inline-block;padding:12px;border-radius:8px;text-align:center;margin:4px;min-width:110px;border:1px solid #ddd}.sl{font-size:9px;color:#888;text-transform:uppercase}.sv{font-size:22px;font-weight:800}.ss{font-size:9px;color:#aaa}</style></head><body>${el.innerHTML}</body></html>`);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); w.close(); }, 500);
}

// ======= PAST RESULTS =======
function initHist() {
  const sel = $('hf-stu');
  sel.innerHTML = '<option value="all">All Students</option>';
  const sids = [...new Set(D.history.map(h => h.sid))];
  sids.forEach(sid => {
    const stu = D.students.find(s => s.id === sid);
    const name = stu ? (stu.fn + ' ' + stu.ln) : (D.history.find(h => h.sid === sid)?.studentName || 'Unknown');
    const o = document.createElement('option');
    o.value = sid;
    o.textContent = name;
    sel.appendChild(o);
  });
  rHist();
}

function rHist() {
  const sf = $('hf-stu').value;
  const ff = $('hf-form').value;
  let recs = [...D.history];
  if (sf !== 'all') recs = recs.filter(h => h.sid === +sf);
  if (ff !== 'all') recs = recs.filter(h => h.archivedForm === +ff);

  if (!recs.length) {
    $('hist-area').innerHTML = '<div class="cd" style="text-align:center;color:#bbb;padding:32px">' + (D.history.length ? 'No records match filter.' : 'No archived results yet. Results are archived when students are promoted.') + '</div>';
    return;
  }

  const grouped = {};
  recs.forEach(r => {
    const key = r.sid;
    if (!grouped[key]) grouped[key] = { sid: r.sid, name: r.studentName || 'Unknown', records: [] };
    grouped[key].records.push(r);
  });

  let h = '';
  Object.values(grouped).forEach(g => {
    const stu = D.students.find(s => s.id === g.sid);
    const currentForm = stu ? 'Form ' + stu.form : '(deleted)';
    h += `<div class="cd" style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px"><div><b style="font-size:15px;color:#1a1a2e">${g.name}</b><span style="margin-left:10px;font-size:11px;color:#888">Now: ${currentForm}</span></div><span style="font-size:10px;color:#0f3460;font-weight:600">${g.records.length} archived exam(s)</span></div>`;

    g.records.forEach(r => {
      const isA = r.archivedForm >= 5;
      const subs = Object.keys(r.marks).filter(k => r.marks[k] !== '');
      const sr2 = subs.map(sub => { const m = parseInt(r.marks[sub]) || 0; const g2 = gr(m, r.archivedForm); return { sub, m, g: g2.g, p: g2.p, r: g2.r }; });
      const tot = sr2.reduce((s, x) => s + x.m, 0);
      const avg = sr2.length ? (tot / sr2.length).toFixed(1) : '0';
      const best2 = [...sr2].sort((a, b) => a.p - b.p).slice(0, isA ? 3 : 7);
      const pts = best2.reduce((s, x) => s + x.p, 0);
      const div2 = dv(pts, r.archivedForm);

      h += `<div style="margin-bottom:10px;padding:12px;background:#fafafa;border-radius:8px;border:1px solid #eee">`;
      h += `<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><span style="font-weight:700;font-size:13px;color:#0f3460">Form ${r.archivedForm} — ${r.exam} (${r.term} ${r.yr || ''})</span><span style="font-size:10px;color:#888">Archived: ${r.archivedDate || '—'}</span></div>`;
      h += '<div class="tbl-wrap"><table style="font-size:11px"><thead><tr style="background:#1a1a2e;color:#fff"><th style="padding:5px 8px">#</th><th style="padding:5px 8px">Subject</th><th style="padding:5px 8px;text-align:center">Marks</th><th style="padding:5px 8px;text-align:center">Grade</th><th style="padding:5px 8px;text-align:center">Pts</th></tr></thead><tbody>';
      sr2.forEach((x, i) => {
        h += `<tr><td style="padding:4px 8px;color:#888">${i + 1}</td><td style="padding:4px 8px">${x.sub}</td><td style="padding:4px 8px;text-align:center;font-weight:600">${x.m}</td><td style="padding:4px 8px;text-align:center;font-weight:700;color:${x.g === 'A' ? '#16c79a' : x.g === 'F' ? '#e94560' : '#333'}">${x.g}</td><td style="padding:4px 8px;text-align:center">${x.p}</td></tr>`;
      });
      h += '</tbody></table></div>';
      h += `<div style="margin-top:8px;display:flex;gap:8px;font-size:11px;flex-wrap:wrap"><span style="padding:3px 10px;background:#e8eaf6;border-radius:6px"><b>Total:</b> ${tot}</span><span style="padding:3px 10px;background:#e3f2fd;border-radius:6px"><b>Avg:</b> ${avg}%</span><span style="padding:3px 10px;background:#fff3e0;border-radius:6px"><b>Best ${isA ? '3' : '7'} Pts:</b> ${pts}</span><span style="padding:3px 10px;background:${div2 === 'I' ? '#e8f5e9' : div2 === 'II' ? '#e3f2fd' : '#fce4ec'};border-radius:6px"><b>Div:</b> ${div2 === '0' ? 'Fail' : div2}</span></div>`;
      h += `</div>`;
    });
    h += `</div>`;
  });
  $('hist-area').innerHTML = h;
}

// ======= PROMOTION =======
function previewPromo() {
  const exam = $('promo-exam').value;
  const term = $('promo-term').value;
  const form = +$('promo-form').value;
  const nextForm = form + 1;
  if (nextForm > 6) {
    $('promo-preview').innerHTML = '<div style="color:#e94560;font-size:13px;padding:10px">Form 6 students cannot be promoted further (they graduate).</div>';
    return;
  }
  const sts = D.students.filter(s => s.form === form);
  if (!sts.length) {
    $('promo-preview').innerHTML = '<div style="color:#888;font-size:13px;padding:10px">No students in Form ' + form + '.</div>';
    return;
  }

  const withExam = [];
  const withoutExam = [];
  sts.forEach(s => {
    const hasEx = D.exams.find(e => e.sid === s.id && e.exam === exam && e.term === term);
    if (hasEx) withExam.push(s); else withoutExam.push(s);
  });

  let h = '<div style="margin-bottom:10px;font-size:13px"><b>Form ' + form + ' → Form ' + nextForm + '</b> | ' + exam + ' (' + term + ')</div>';
  h += '<div class="tbl-wrap"><table><thead><tr><th>#</th><th>Adm</th><th>Name</th><th>Status</th></tr></thead><tbody>';
  withExam.forEach((s, i) => {
    h += `<tr style="background:#e8f5e9"><td>${i + 1}</td><td style="font-weight:600">${s.adm || '—'}</td><td>${s.fn} ${s.mn} ${s.ln}</td><td><span style="color:#2e7d32;font-weight:700">✅ Will be promoted to Form ${nextForm}</span></td></tr>`;
  });
  withoutExam.forEach((s, i) => {
    h += `<tr style="background:#ffebee"><td>${withExam.length + i + 1}</td><td style="font-weight:600">${s.adm || '—'}</td><td style="color:#c62828;font-weight:600">${s.fn} ${s.mn} ${s.ln}</td><td><span style="color:#c62828;font-weight:700">❌ NO EXAM — will NOT be promoted</span></td></tr>`;
  });
  h += '</tbody></table></div>';
  h += `<div style="margin-top:14px;padding:12px;background:#fffde7;border:1px solid #ffe082;border-radius:8px;font-size:12px;color:#5d4037"><b>Summary:</b> ${withExam.length} students will be promoted to Form ${nextForm}. ${withoutExam.length} students flagged (no ${exam} results).</div>`;
  if (withExam.length > 0) {
    h += `<div style="margin-top:12px"><button class="bt bg" onclick="execPromo(${form},'${exam}','${term}')" style="font-size:13px">✓ Confirm Promotion (${withExam.length} students)</button></div>`;
  }
  $('promo-preview').innerHTML = h;
}

function execPromo(form, exam, term) {
  const nextForm = form + 1;
  let promoted = 0;
  const now = new Date().toISOString().split('T')[0];
  D.students.forEach(s => {
    if (s.form !== form) return;
    const hasEx = D.exams.find(e => e.sid === s.id && e.exam === exam && e.term === term);
    if (hasEx) {
      const stuExams = D.exams.filter(e => e.sid === s.id);
      stuExams.forEach(ex => {
        D.history.push({ ...ex, archivedForm: form, archivedDate: now, studentName: s.fn + ' ' + (s.mn || '') + ' ' + s.ln });
      });
      D.exams = D.exams.filter(e => e.sid !== s.id);
      Object.keys(D.att).forEach(d => { if (D.att[d]?.[s.id]) delete D.att[d][s.id]; });
      s.form = nextForm;
      if (nextForm <= 2) { s.stream = ''; s.combo = ''; s.dropped = []; }
      if (nextForm >= 3 && nextForm <= 4 && !s.stream) { s.stream = ''; s.dropped = []; }
      if (nextForm >= 5) { s.combo = ''; s.stream = ''; s.dropped = []; }
      promoted++;
    }
  });
  sv();
  $('promo-preview').innerHTML = `<div class="ok">✅ ${promoted} students promoted from Form ${form} to Form ${nextForm}!<br><span style="font-size:12px;font-weight:400">Previous results archived. Current exams & attendance cleared for fresh start.</span>${nextForm === 3 || nextForm === 5 ? '<br><b>⚠ Note:</b> Promoted students need stream/combination assigned — edit them in Students list.' : ''}</div>`;
  rDash();
}

// ======= START =======
init();
