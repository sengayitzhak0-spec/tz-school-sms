# 🇹🇿 Tanzania School Management System

A full-stack school management application built with **C++** (backend server), **HTML** (structure), **CSS** (styling), and **JavaScript** (client logic).

## Architecture

```
tanzania-sms/
├── server.cpp          # C++ HTTP server with REST API
├── Makefile            # Build system
├── data.json           # Persistent data storage (auto-created)
├── backups/            # Backup files (auto-created)
└── public/             # Static web files
    ├── index.html      # HTML frontend
    ├── style.css       # CSS stylesheet
    └── app.js          # JavaScript application logic
```

### How It Works

- **C++ Backend (`server.cpp`)**: A multi-threaded HTTP server using POSIX sockets that:
  - Serves static files (HTML, CSS, JS) from the `public/` directory
  - Provides a REST API for loading and saving application data
  - Persists data to `data.json` on disk (replaces the original's localStorage)
  - Supports atomic file writes, backups, and data export
  - Handles concurrent connections via threading

- **HTML (`index.html`)**: The page structure for all views — dashboard, registration, student list, attendance, exams, reports, past results

- **CSS (`style.css`)**: Complete responsive styling with mobile support, dark sidebar, cards, tables, forms, modals, and print styles

- **JavaScript (`app.js`)**: Client-side logic that communicates with the C++ server via `fetch()` API calls for all data operations

## Prerequisites

- **g++** with C++17 support (GCC 8+ or Clang 7+)
- **Linux/macOS** (uses POSIX sockets)
- A modern web browser

## Quick Start

```bash
# 1. Build the server
make

# 2. Run (default port 8080)
make run

# 3. Open in browser
# → http://localhost:8080
```

### Custom Port

```bash
make run PORT=3000
# → http://localhost:3000
```

## API Endpoints

| Method | Endpoint       | Description              |
|--------|---------------|--------------------------|
| GET    | `/api/data`    | Load all application data |
| POST   | `/api/data`    | Save all application data |
| POST   | `/api/backup`  | Create a data backup      |
| GET    | `/api/backup`  | List available backups    |
| GET    | `/api/export`  | Download data as JSON     |
| GET    | `/api/health`  | Server health check       |

## Features

- **Dashboard**: Student statistics, enrollment breakdown by form, daily attendance summary
- **Student Registration**: Full registration with Tanzania curriculum (O-Level & A-Level), stream/combination selection, subject management
- **Student List**: Searchable, filterable student directory with edit/delete
- **Attendance**: Daily attendance marking with P/A/L status, batch operations, submission tracking
- **Attendance History**: Searchable attendance records with statistics
- **Exam Results**: NECTA-aligned grading for both O-Level (CSEE) and A-Level (ACSEE), real-time grade calculation
- **Academic Reports**: Professional printable/downloadable report cards with rankings
- **Past Results**: Archived results from previous forms (preserved during promotion)
- **Year-End Promotion**: Promote students between forms with exam verification
- **Data Management**: Server-side persistence, backup creation, JSON data export

## Tanzania Curriculum Support

- **O-Level (Forms 1-4)**: NECTA CSEE grading (A-F, 5 grades, 1-5 points)
- **A-Level (Forms 5-6)**: NECTA ACSEE grading (A-F, 7 grades, 1-7 points)
- **Streams**: Science, Arts, Business (Forms 3-4)
- **Combinations**: 13 standard A-Level subject combinations (PCB, PCM, HGE, ECA, etc.)
- **Division Calculation**: Based on best 7 (O-Level) or best 3 (A-Level) subjects
- **All 31 Tanzania Regions** available for student registration

## Makefile Commands

```bash
make          # Build the server
make run      # Build and run
make clean    # Remove binary and backups
make reset    # Remove binary, backups, and all data
make help     # Show available commands
```
